﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KarolOchoa_Actividad1_Escritorio
{
    public partial class Form1 : Form
    {
        public object Messagebox { get; private set; }

        public Form1() => InitializeComponent();

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void botonguardar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Datos guardados correctamente");

        }
    }
}
