﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KarolOchoa_Actividad1_Consola
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //VARIABLES//
            String nombre;
            String edad;
            String fecha_nac;
            string carrera;
            String salir;

            //CAPTURAR DATOS//
            Console.WriteLine("Bienvenido a UMI/Universidad Coppel\n");
            Console.WriteLine("Ingrese los siguientes datos:\n");
            Console.WriteLine("Nombre completo: ");
            nombre = Console.ReadLine();
            Console.WriteLine("\nEdad: ");
            edad = Console.ReadLine();
            Console.WriteLine("\nFecha de nacimiento (DD/MM/AAAA): ");
            fecha_nac = Console.ReadLine();
            Console.WriteLine("\nCarrera a la que deseas ingresar: ");
            carrera = Console.ReadLine();

            //IMPRIMIR DATOS//
            Console.WriteLine("\n\n¡Gracias " + nombre + " por formar parte de UMI/Universidad Coppel!\n Bienvenido a la carrera de " + carrera + ".");
            Console.WriteLine("\nNombre:" + nombre + ".");
            Console.WriteLine("Edad:" + edad + " años.");
            Console.WriteLine("Fecha de nacimiento:" + fecha_nac + ".");
            Console.WriteLine("Carrera:" + carrera + ".");
            Console.WriteLine("\n\n");

            //SALIR DEL PROGRAMA//
           Console.WriteLine("Presione cualquier tecla para salir...");
            salir = Console.ReadLine();



        }
    }
}
