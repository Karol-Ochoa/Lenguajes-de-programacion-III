﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KarolOchoa_Actividad2_Escritorio
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void contextMenuStrip2_Opening(object sender, CancelEventArgs e)
        {

        }

        private void saludoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FORMULARIO.FormSaludo formSaludo = new FORMULARIO.FormSaludo();
            formSaludo.Show();

        }

        private void InformacionPersonalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FORMULARIO.FormInformacionPersonal FormInformacionPersonal = new FORMULARIO.FormInformacionPersonal();
            FormInformacionPersonal.Show();
        }

        private void operacionesBásicasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FORMULARIO.FormOperacionesBasicas FormOperacionesBasicas = new FORMULARIO.FormOperacionesBasicas();
            FormOperacionesBasicas.Show();
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
