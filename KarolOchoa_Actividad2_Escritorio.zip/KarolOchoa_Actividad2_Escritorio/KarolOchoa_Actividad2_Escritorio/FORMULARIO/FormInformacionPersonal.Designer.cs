﻿namespace KarolOchoa_Actividad2_Escritorio.FORMULARIO
{
    partial class FormInformacionPersonal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormInformacionPersonal));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.TabPageDatosPersonales = new System.Windows.Forms.TabPage();
            this.ButtonRegresarDP = new System.Windows.Forms.Button();
            this.RadioButtonHombre = new System.Windows.Forms.RadioButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.PictureBoxMujer = new System.Windows.Forms.PictureBox();
            this.RadioButtonMujer = new System.Windows.Forms.RadioButton();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.TextNombre = new System.Windows.Forms.TextBox();
            this.MensajeDatosPersonales = new System.Windows.Forms.Label();
            this.LabelSexo = new System.Windows.Forms.Label();
            this.LabelEstadoCivil = new System.Windows.Forms.Label();
            this.LabelFecNac = new System.Windows.Forms.Label();
            this.LabelDireccion = new System.Windows.Forms.Label();
            this.LabelApellido = new System.Windows.Forms.Label();
            this.LabelNombre = new System.Windows.Forms.Label();
            this.TabPageDatosClinicos = new System.Windows.Forms.TabPage();
            this.ButtonRegresarDC = new System.Windows.Forms.Button();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.tabControl1.SuspendLayout();
            this.TabPageDatosPersonales.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBoxMujer)).BeginInit();
            this.TabPageDatosClinicos.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.TabPageDatosPersonales);
            this.tabControl1.Controls.Add(this.TabPageDatosClinicos);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(776, 486);
            this.tabControl1.TabIndex = 0;
            // 
            // TabPageDatosPersonales
            // 
            this.TabPageDatosPersonales.Controls.Add(this.ButtonRegresarDP);
            this.TabPageDatosPersonales.Controls.Add(this.RadioButtonHombre);
            this.TabPageDatosPersonales.Controls.Add(this.pictureBox1);
            this.TabPageDatosPersonales.Controls.Add(this.PictureBoxMujer);
            this.TabPageDatosPersonales.Controls.Add(this.RadioButtonMujer);
            this.TabPageDatosPersonales.Controls.Add(this.comboBox1);
            this.TabPageDatosPersonales.Controls.Add(this.dateTimePicker1);
            this.TabPageDatosPersonales.Controls.Add(this.textBox2);
            this.TabPageDatosPersonales.Controls.Add(this.textBox1);
            this.TabPageDatosPersonales.Controls.Add(this.TextNombre);
            this.TabPageDatosPersonales.Controls.Add(this.MensajeDatosPersonales);
            this.TabPageDatosPersonales.Controls.Add(this.LabelSexo);
            this.TabPageDatosPersonales.Controls.Add(this.LabelEstadoCivil);
            this.TabPageDatosPersonales.Controls.Add(this.LabelFecNac);
            this.TabPageDatosPersonales.Controls.Add(this.LabelDireccion);
            this.TabPageDatosPersonales.Controls.Add(this.LabelApellido);
            this.TabPageDatosPersonales.Controls.Add(this.LabelNombre);
            this.TabPageDatosPersonales.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TabPageDatosPersonales.Location = new System.Drawing.Point(4, 22);
            this.TabPageDatosPersonales.Name = "TabPageDatosPersonales";
            this.TabPageDatosPersonales.Padding = new System.Windows.Forms.Padding(3);
            this.TabPageDatosPersonales.Size = new System.Drawing.Size(768, 460);
            this.TabPageDatosPersonales.TabIndex = 0;
            this.TabPageDatosPersonales.Text = "Datos Personales";
            this.TabPageDatosPersonales.UseVisualStyleBackColor = true;
            this.TabPageDatosPersonales.Click += new System.EventHandler(this.TabPageDatosPersonales_Click);
            // 
            // ButtonRegresarDP
            // 
            this.ButtonRegresarDP.BackColor = System.Drawing.Color.Navy;
            this.ButtonRegresarDP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonRegresarDP.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonRegresarDP.ForeColor = System.Drawing.Color.White;
            this.ButtonRegresarDP.Location = new System.Drawing.Point(677, 427);
            this.ButtonRegresarDP.Name = "ButtonRegresarDP";
            this.ButtonRegresarDP.Size = new System.Drawing.Size(85, 27);
            this.ButtonRegresarDP.TabIndex = 17;
            this.ButtonRegresarDP.Text = "Regresar";
            this.ButtonRegresarDP.UseVisualStyleBackColor = false;
            this.ButtonRegresarDP.Click += new System.EventHandler(this.ButtonRegresarDP_Click);
            // 
            // RadioButtonHombre
            // 
            this.RadioButtonHombre.AutoSize = true;
            this.RadioButtonHombre.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RadioButtonHombre.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RadioButtonHombre.Location = new System.Drawing.Point(519, 245);
            this.RadioButtonHombre.Name = "RadioButtonHombre";
            this.RadioButtonHombre.Size = new System.Drawing.Size(76, 20);
            this.RadioButtonHombre.TabIndex = 16;
            this.RadioButtonHombre.TabStop = true;
            this.RadioButtonHombre.Text = "Hombre";
            this.RadioButtonHombre.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(598, 240);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(30, 30);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // PictureBoxMujer
            // 
            this.PictureBoxMujer.Image = ((System.Drawing.Image)(resources.GetObject("PictureBoxMujer.Image")));
            this.PictureBoxMujer.Location = new System.Drawing.Point(598, 192);
            this.PictureBoxMujer.Name = "PictureBoxMujer";
            this.PictureBoxMujer.Size = new System.Drawing.Size(30, 30);
            this.PictureBoxMujer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PictureBoxMujer.TabIndex = 14;
            this.PictureBoxMujer.TabStop = false;
            // 
            // RadioButtonMujer
            // 
            this.RadioButtonMujer.AutoSize = true;
            this.RadioButtonMujer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RadioButtonMujer.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RadioButtonMujer.Location = new System.Drawing.Point(523, 193);
            this.RadioButtonMujer.Name = "RadioButtonMujer";
            this.RadioButtonMujer.Size = new System.Drawing.Size(62, 20);
            this.RadioButtonMujer.TabIndex = 13;
            this.RadioButtonMujer.TabStop = true;
            this.RadioButtonMujer.Text = "Mujer";
            this.RadioButtonMujer.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Soltero",
            "Casado ",
            "Divorciado",
            "Viudo"});
            this.comboBox1.Location = new System.Drawing.Point(556, 64);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 22);
            this.comboBox1.TabIndex = 12;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarFont = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dateTimePicker1.Location = new System.Drawing.Point(15, 302);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(376, 22);
            this.dateTimePicker1.TabIndex = 11;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(15, 232);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(376, 25);
            this.textBox2.TabIndex = 9;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(15, 162);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(376, 25);
            this.textBox1.TabIndex = 8;
            // 
            // TextNombre
            // 
            this.TextNombre.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextNombre.Location = new System.Drawing.Point(15, 88);
            this.TextNombre.Name = "TextNombre";
            this.TextNombre.Size = new System.Drawing.Size(376, 25);
            this.TextNombre.TabIndex = 7;
            // 
            // MensajeDatosPersonales
            // 
            this.MensajeDatosPersonales.AutoSize = true;
            this.MensajeDatosPersonales.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MensajeDatosPersonales.ForeColor = System.Drawing.Color.Navy;
            this.MensajeDatosPersonales.Location = new System.Drawing.Point(224, 13);
            this.MensajeDatosPersonales.Name = "MensajeDatosPersonales";
            this.MensajeDatosPersonales.Size = new System.Drawing.Size(310, 25);
            this.MensajeDatosPersonales.TabIndex = 6;
            this.MensajeDatosPersonales.Text = "Ingresa los siguientes datos:";
            // 
            // LabelSexo
            // 
            this.LabelSexo.AutoSize = true;
            this.LabelSexo.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelSexo.ForeColor = System.Drawing.Color.Navy;
            this.LabelSexo.Location = new System.Drawing.Point(439, 63);
            this.LabelSexo.Name = "LabelSexo";
            this.LabelSexo.Size = new System.Drawing.Size(111, 23);
            this.LabelSexo.TabIndex = 5;
            this.LabelSexo.Text = "Estado civil";
            // 
            // LabelEstadoCivil
            // 
            this.LabelEstadoCivil.AutoSize = true;
            this.LabelEstadoCivil.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelEstadoCivil.ForeColor = System.Drawing.Color.Navy;
            this.LabelEstadoCivil.Location = new System.Drawing.Point(519, 162);
            this.LabelEstadoCivil.Name = "LabelEstadoCivil";
            this.LabelEstadoCivil.Size = new System.Drawing.Size(116, 23);
            this.LabelEstadoCivil.TabIndex = 4;
            this.LabelEstadoCivil.Text = "Estado Civil";
            // 
            // LabelFecNac
            // 
            this.LabelFecNac.AutoSize = true;
            this.LabelFecNac.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelFecNac.ForeColor = System.Drawing.Color.Navy;
            this.LabelFecNac.Location = new System.Drawing.Point(15, 278);
            this.LabelFecNac.Name = "LabelFecNac";
            this.LabelFecNac.Size = new System.Drawing.Size(188, 23);
            this.LabelFecNac.TabIndex = 3;
            this.LabelFecNac.Text = "Fecha de Nacimiento";
            // 
            // LabelDireccion
            // 
            this.LabelDireccion.AutoSize = true;
            this.LabelDireccion.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelDireccion.ForeColor = System.Drawing.Color.Navy;
            this.LabelDireccion.Location = new System.Drawing.Point(15, 206);
            this.LabelDireccion.Name = "LabelDireccion";
            this.LabelDireccion.Size = new System.Drawing.Size(93, 23);
            this.LabelDireccion.TabIndex = 2;
            this.LabelDireccion.Text = "Dirección";
            // 
            // LabelApellido
            // 
            this.LabelApellido.AutoSize = true;
            this.LabelApellido.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelApellido.ForeColor = System.Drawing.Color.Navy;
            this.LabelApellido.Location = new System.Drawing.Point(15, 136);
            this.LabelApellido.Name = "LabelApellido";
            this.LabelApellido.Size = new System.Drawing.Size(85, 23);
            this.LabelApellido.TabIndex = 1;
            this.LabelApellido.Text = "Apellido";
            // 
            // LabelNombre
            // 
            this.LabelNombre.AutoSize = true;
            this.LabelNombre.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelNombre.ForeColor = System.Drawing.Color.Navy;
            this.LabelNombre.Location = new System.Drawing.Point(15, 63);
            this.LabelNombre.Name = "LabelNombre";
            this.LabelNombre.Size = new System.Drawing.Size(79, 23);
            this.LabelNombre.TabIndex = 0;
            this.LabelNombre.Text = "Nombre";
            // 
            // TabPageDatosClinicos
            // 
            this.TabPageDatosClinicos.Controls.Add(this.groupBox5);
            this.TabPageDatosClinicos.Controls.Add(this.groupBox4);
            this.TabPageDatosClinicos.Controls.Add(this.groupBox3);
            this.TabPageDatosClinicos.Controls.Add(this.groupBox2);
            this.TabPageDatosClinicos.Controls.Add(this.groupBox1);
            this.TabPageDatosClinicos.Controls.Add(this.ButtonRegresarDC);
            this.TabPageDatosClinicos.Controls.Add(this.label6);
            this.TabPageDatosClinicos.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TabPageDatosClinicos.Location = new System.Drawing.Point(4, 22);
            this.TabPageDatosClinicos.Name = "TabPageDatosClinicos";
            this.TabPageDatosClinicos.Padding = new System.Windows.Forms.Padding(3);
            this.TabPageDatosClinicos.Size = new System.Drawing.Size(768, 460);
            this.TabPageDatosClinicos.TabIndex = 1;
            this.TabPageDatosClinicos.Text = "Datos Clinicos";
            this.TabPageDatosClinicos.UseVisualStyleBackColor = true;
            this.TabPageDatosClinicos.Click += new System.EventHandler(this.TabPageDatosClinicos_Click);
            // 
            // ButtonRegresarDC
            // 
            this.ButtonRegresarDC.BackColor = System.Drawing.Color.Navy;
            this.ButtonRegresarDC.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonRegresarDC.ForeColor = System.Drawing.Color.White;
            this.ButtonRegresarDC.Location = new System.Drawing.Point(677, 427);
            this.ButtonRegresarDC.Name = "ButtonRegresarDC";
            this.ButtonRegresarDC.Size = new System.Drawing.Size(85, 27);
            this.ButtonRegresarDC.TabIndex = 38;
            this.ButtonRegresarDC.Text = "Regresar";
            this.ButtonRegresarDC.UseVisualStyleBackColor = false;
            this.ButtonRegresarDC.Click += new System.EventHandler(this.ButtonRegresarDC_Click);
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "Caminata rápida",
            "Trote o carrera (Running)",
            "Ciclismo (Bicicleta)",
            "Natación",
            "Remo",
            "Elíptica",
            "Salto de cuerda",
            "Baile / Zumba",
            "Levantamiento de pesas",
            "Calistenia ",
            "Entrenamiento con bandas de resistencia",
            "Crossfit",
            "Powerlifting",
            "Yoga",
            "Pilates",
            "Estiramientos estáticos y dinámicos",
            "Tai Chi",
            "Ejercicios de liberación miofascial (Uso de rodillo/foam roller)",
            "Ejercicios en superficies inestables (Bosu / Fitball)",
            "Artes marciales",
            "Gimnasia rítmica o artística",
            "Ninguna de los anteriores"});
            this.comboBox5.Location = new System.Drawing.Point(10, 101);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(255, 22);
            this.comboBox5.TabIndex = 37;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Navy;
            this.label10.Location = new System.Drawing.Point(6, 75);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(272, 23);
            this.label10.TabIndex = 36;
            this.label10.Text = "¿Qué tipo de ejercicio realizas?\r\n";
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "Apendicitis (Apendicectomía)",
            "Colecistitis / Piedras en la vesícula (Colecistectomía)",
            "Hernia inguinal / umbilical / hiatal",
            "Hemorroides",
            "Pólipos de colon",
            "Fracturas óseas",
            "Rotura de ligamentos (LCA / Meniscos)",
            "Túnel carpiano",
            "Prótesis de cadera o rodilla",
            "Juanetes (Hallux Valgus)",
            "Extracción de tumores / Quistes",
            "Biopsia quirúrgica",
            "Mastectomía",
            "Bypass coronario",
            "Colocación de marcapasos",
            "Varices",
            "Cálculos renales",
            "Histerectomía",
            "Quistes ováricos",
            "Cirugía de próstata",
            "Vasectomía / Ligadura de trompas",
            "Cataratas",
            "Amígdalas / Adenoides",
            "Desviación del tabique nasal (Septoplastia)",
            "Cesárea",
            "Ninguna de las anteriores"});
            this.comboBox4.Location = new System.Drawing.Point(24, 106);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(255, 22);
            this.comboBox4.TabIndex = 35;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Navy;
            this.label9.Location = new System.Drawing.Point(6, 80);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(186, 23);
            this.label9.TabIndex = 34;
            this.label9.Text = "¿Cuál fue el motivo?";
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Penicilina y derivados (Amoxicilina, Ampicilina)",
            "AINES (Aspirina, Ibuprofeno, Naproxeno)",
            "Sulfas (Sulfametoxazol)",
            "Anticonvulsivantes",
            "Insulina",
            "Medios de contraste yodados (usados en rayos X)",
            "Leche de vaca (Lactosa/Proteína de leche)",
            "Huevo",
            "Frutos secos (Maní, nueces, almendras, avellanas)",
            "Mariscos (Camarones, langosta, cangrejo)",
            "Pescados",
            "Trigo (Gluten / Celiaquía)",
            "Soja",
            "Frutas (Fresa, melocotón, kiwi)",
            "Polen (pastos, malezas, árboles)",
            "Ácaros del polvo",
            "Moho / Hongos",
            "Caspa de animales (perros, gatos, caballos)",
            "Picadura de insectos (Abejas, avispas, hormigas rojas)",
            "Látex (guantes, preservativos, globos)",
            "Níquel (joyas, relojes, hebillas)",
            "Fragancias o perfumes",
            "Conservantes químicos en cosméticos",
            "Ninguna de las anteriores"});
            this.comboBox3.Location = new System.Drawing.Point(10, 106);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(255, 22);
            this.comboBox3.TabIndex = 33;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Navy;
            this.label8.Location = new System.Drawing.Point(6, 80);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(168, 23);
            this.label8.TabIndex = 32;
            this.label8.Text = "¿Qué alergias son?";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Diabetes",
            "Hipertensión arterial",
            "Hipercolesterolemia (Colesterol alto)",
            "Hipotiroidismo / Hipertiroidismo",
            "Obesidad",
            "Asma",
            "Arritmias o soplos cardíacos",
            "Insuficiencia cardíaca",
            "Tuberculosis",
            "Epilepsia",
            "Migraña crónica",
            "Trastorno de ansiedad",
            "Trastorno por Déficit de Atención (TDAH)",
            "Esclerosis múltiple",
            "Artritis / Artrosis",
            "Lupus",
            "Fibromialgia",
            "Hernias discales",
            "Cáncer",
            "VIH / SIDA",
            "Hepatitis",
            "Insuficiencia renal / Cálculos renales",
            "Gastritis / Úlceras gástricas",
            "Ninguna de las anteriores"});
            this.comboBox2.Location = new System.Drawing.Point(16, 113);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(255, 22);
            this.comboBox2.TabIndex = 31;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Navy;
            this.label7.Location = new System.Drawing.Point(12, 84);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(189, 23);
            this.label7.TabIndex = 30;
            this.label7.Text = "¿Qué enfermedad es?";
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton9.Location = new System.Drawing.Point(82, 44);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(44, 20);
            this.radioButton9.TabIndex = 29;
            this.radioButton9.TabStop = true;
            this.radioButton9.Text = "No";
            this.radioButton9.UseVisualStyleBackColor = true;
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton10.Location = new System.Drawing.Point(28, 44);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(37, 20);
            this.radioButton10.TabIndex = 28;
            this.radioButton10.TabStop = true;
            this.radioButton10.Text = "Si";
            this.radioButton10.UseVisualStyleBackColor = true;
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton7.Location = new System.Drawing.Point(94, 44);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(44, 20);
            this.radioButton7.TabIndex = 27;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "No";
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton8.Location = new System.Drawing.Point(39, 44);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(37, 20);
            this.radioButton8.TabIndex = 26;
            this.radioButton8.TabStop = true;
            this.radioButton8.Text = "Si";
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton5.Location = new System.Drawing.Point(103, 44);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(44, 20);
            this.radioButton5.TabIndex = 25;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "No";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton6.Location = new System.Drawing.Point(48, 44);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(37, 20);
            this.radioButton6.TabIndex = 24;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "Si";
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton3.Location = new System.Drawing.Point(87, 44);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(44, 20);
            this.radioButton3.TabIndex = 23;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "No";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton4.Location = new System.Drawing.Point(30, 44);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(37, 20);
            this.radioButton4.TabIndex = 22;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Si";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton1.Location = new System.Drawing.Point(106, 44);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(44, 20);
            this.radioButton1.TabIndex = 21;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "No";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton2.Location = new System.Drawing.Point(43, 44);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(37, 20);
            this.radioButton2.TabIndex = 20;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Si";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Navy;
            this.label6.Location = new System.Drawing.Point(225, 16);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(310, 25);
            this.label6.TabIndex = 19;
            this.label6.Text = "Ingresa los siguientes datos:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Navy;
            this.label5.Location = new System.Drawing.Point(6, 18);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(208, 23);
            this.label5.TabIndex = 18;
            this.label5.Text = "¿Padeces de depresión?";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Navy;
            this.label4.Location = new System.Drawing.Point(6, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(155, 23);
            this.label4.TabIndex = 17;
            this.label4.Text = "¿Haces ejercicio?";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Navy;
            this.label3.Location = new System.Drawing.Point(6, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(255, 23);
            this.label3.TabIndex = 16;
            this.label3.Text = "¿Alguna vez te han operado?";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Navy;
            this.label2.Location = new System.Drawing.Point(6, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(154, 23);
            this.label2.TabIndex = 15;
            this.label2.Text = "¿Tienes alergias?";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Navy;
            this.label1.Location = new System.Drawing.Point(6, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(286, 23);
            this.label1.TabIndex = 13;
            this.label1.Text = "¿Padeces de alguna enfermedad?";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.radioButton2);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.comboBox2);
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Location = new System.Drawing.Point(26, 57);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(311, 141);
            this.groupBox1.TabIndex = 39;
            this.groupBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.radioButton10);
            this.groupBox2.Controls.Add(this.radioButton9);
            this.groupBox2.Location = new System.Drawing.Point(406, 351);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(265, 103);
            this.groupBox2.TabIndex = 40;
            this.groupBox2.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.comboBox3);
            this.groupBox3.Controls.Add(this.radioButton3);
            this.groupBox3.Controls.Add(this.radioButton4);
            this.groupBox3.Location = new System.Drawing.Point(26, 234);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(311, 141);
            this.groupBox3.TabIndex = 41;
            this.groupBox3.TabStop = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.radioButton6);
            this.groupBox4.Controls.Add(this.radioButton5);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.comboBox4);
            this.groupBox4.Location = new System.Drawing.Point(407, 50);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(311, 141);
            this.groupBox4.TabIndex = 42;
            this.groupBox4.TabStop = false;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.radioButton8);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.comboBox5);
            this.groupBox5.Controls.Add(this.radioButton7);
            this.groupBox5.Location = new System.Drawing.Point(407, 204);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(311, 141);
            this.groupBox5.TabIndex = 41;
            this.groupBox5.TabStop = false;
            // 
            // FormInformacionPersonal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 510);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormInformacionPersonal";
            this.Text = "InformacionPersonal";
            this.tabControl1.ResumeLayout(false);
            this.TabPageDatosPersonales.ResumeLayout(false);
            this.TabPageDatosPersonales.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBoxMujer)).EndInit();
            this.TabPageDatosClinicos.ResumeLayout(false);
            this.TabPageDatosClinicos.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage TabPageDatosPersonales;
        private System.Windows.Forms.TabPage TabPageDatosClinicos;
        private System.Windows.Forms.Label MensajeDatosPersonales;
        private System.Windows.Forms.Label LabelEstadoCivil;
        private System.Windows.Forms.Label LabelFecNac;
        private System.Windows.Forms.Label LabelDireccion;
        private System.Windows.Forms.Label LabelApellido;
        private System.Windows.Forms.Label LabelNombre;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox TextNombre;
        private System.Windows.Forms.RadioButton RadioButtonMujer;
        private System.Windows.Forms.PictureBox PictureBoxMujer;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.RadioButton RadioButtonHombre;
        private System.Windows.Forms.Button ButtonRegresarDP;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label LabelSexo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button ButtonRegresarDC;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox4;
    }
}