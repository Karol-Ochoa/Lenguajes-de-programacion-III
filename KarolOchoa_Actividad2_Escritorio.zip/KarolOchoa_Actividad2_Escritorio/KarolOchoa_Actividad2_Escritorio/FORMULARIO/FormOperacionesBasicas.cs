﻿using KarolOchoa_Actividad2_Escritorio.CLASE;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KarolOchoa_Actividad2_Escritorio.FORMULARIO
{
    public partial class FormOperacionesBasicas : Form
    {
        public FormOperacionesBasicas()
        {
            InitializeComponent();
        }

        private void MensajeDatosPersonales_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
           this.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            int resultado;
            CLASE.ClassResta ClassResta = new CLASE.ClassResta();
            resultado = ClassResta.Resta(int.Parse(textNum1.Text), int.Parse(textNum2.Text), int.Parse(textNum3.Text),
                int.Parse(textNum4.Text), int.Parse(textNum5.Text), int.Parse(textNum6.Text));
            textResultado.Text = resultado.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int resultado;
            CLASE.ClassMultiplicar ClassMultiplicar = new CLASE.ClassMultiplicar();
            resultado = ClassMultiplicar.Multiplicar(int.Parse(textNum1.Text), int.Parse(textNum2.Text), int.Parse(textNum3.Text),
                int.Parse(textNum4.Text), int.Parse(textNum5.Text), int.Parse(textNum6.Text));
            textResultado.Text = resultado.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            float resultado;
            CLASE.ClassDividir ClassDividir = new CLASE.ClassDividir();
            resultado = ClassDividir.Dividir(float.Parse(textNum1.Text), float.Parse(textNum2.Text), float.Parse(textNum3.Text),
                float.Parse(textNum4.Text), float.Parse(textNum5.Text), float.Parse(textNum6.Text));
            textResultado.Text = resultado.ToString();
        }

        private void ButtonSuma_Click(object sender, EventArgs e)
        {
            int resultado;
            CLASE.ClassSuma ClassSuma = new CLASE.ClassSuma();
            resultado = ClassSuma.Suma(int.Parse(textNum1.Text), int.Parse(textNum2.Text), int.Parse(textNum3.Text),
                int.Parse(textNum4.Text), int.Parse(textNum5.Text), int.Parse(textNum6.Text));
            textResultado.Text = resultado.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textResultado.Clear();
        }

        private void textResultado_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
