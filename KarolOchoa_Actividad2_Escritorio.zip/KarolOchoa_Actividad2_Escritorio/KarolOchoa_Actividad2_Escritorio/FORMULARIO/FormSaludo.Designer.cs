﻿namespace KarolOchoa_Actividad2_Escritorio.FORMULARIO
{
    partial class FormSaludo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormSaludo));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxNombre = new System.Windows.Forms.TextBox();
            this.buttonsaludo = new System.Windows.Forms.Button();
            this.buttonregresar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Navy;
            this.label1.Location = new System.Drawing.Point(201, 87);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(187, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ingresa tu nombre";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.label2.Font = new System.Drawing.Font("Mongolian Baiti", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Navy;
            this.label2.Location = new System.Drawing.Point(151, 39);
            this.label2.Margin = new System.Windows.Forms.Padding(0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(276, 30);
            this.label2.TabIndex = 1;
            this.label2.Text = "¡Queremos conocerte!";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textBoxNombre
            // 
            this.textBoxNombre.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNombre.Location = new System.Drawing.Point(124, 131);
            this.textBoxNombre.Name = "textBoxNombre";
            this.textBoxNombre.Size = new System.Drawing.Size(344, 26);
            this.textBoxNombre.TabIndex = 2;
            this.textBoxNombre.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxNombre.TextChanged += new System.EventHandler(this.textBoxNombre_TextChanged);
            // 
            // buttonsaludo
            // 
            this.buttonsaludo.BackColor = System.Drawing.Color.Navy;
            this.buttonsaludo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonsaludo.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonsaludo.ForeColor = System.Drawing.Color.White;
            this.buttonsaludo.Location = new System.Drawing.Point(245, 182);
            this.buttonsaludo.Name = "buttonsaludo";
            this.buttonsaludo.Size = new System.Drawing.Size(90, 33);
            this.buttonsaludo.TabIndex = 3;
            this.buttonsaludo.Text = "Guardar";
            this.buttonsaludo.UseVisualStyleBackColor = false;
            this.buttonsaludo.Click += new System.EventHandler(this.buttonsaludo_Click);
            // 
            // buttonregresar
            // 
            this.buttonregresar.BackColor = System.Drawing.Color.Navy;
            this.buttonregresar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonregresar.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonregresar.ForeColor = System.Drawing.Color.White;
            this.buttonregresar.Location = new System.Drawing.Point(2, 239);
            this.buttonregresar.Name = "buttonregresar";
            this.buttonregresar.Size = new System.Drawing.Size(75, 29);
            this.buttonregresar.TabIndex = 4;
            this.buttonregresar.Text = "Regresar";
            this.buttonregresar.UseVisualStyleBackColor = false;
            this.buttonregresar.Click += new System.EventHandler(this.buttonregresar_Click);
            // 
            // FormSaludo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(593, 270);
            this.Controls.Add(this.buttonregresar);
            this.Controls.Add(this.buttonsaludo);
            this.Controls.Add(this.textBoxNombre);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormSaludo";
            this.Text = "Saludo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxNombre;
        private System.Windows.Forms.Button buttonsaludo;
        private System.Windows.Forms.Button buttonregresar;
    }
}