﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KarolOchoa_Actividad2_Escritorio.FORMULARIO
{
    public partial class FormSaludo : Form
    {
        public FormSaludo()
        {
            InitializeComponent();
        }

        private void buttonsaludo_Click(object sender, EventArgs e)
        {
            CLASE.ClassSaludo saludar = new CLASE.ClassSaludo();
            string saludoTexto = saludar.Saludar(textBoxNombre.Text);
            MessageBox.Show(saludoTexto);
        }

        private void textBoxNombre_TextChanged(object sender, EventArgs e)
        {       

        }

        private void buttonregresar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
