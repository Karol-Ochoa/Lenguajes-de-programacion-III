﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KarolOchoa_Actividad2_Escritorio.FORMULARIO
{
    public partial class FormIngreso : Form
    {
        public FormIngreso()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textIngreso.Text == "")
            {
                MessageBox.Show("Debe ingresar la contraseña.");
            }
            else if (textIngreso.Text == "12345")
            {
                Menu MENU = new Menu();
                MENU.Show();
                this.Hide();
            }
            else
            {     MessageBox.Show("Contraseña incorrecta, intente nuevamente."); 
                textIngreso.Clear();
            }
        }
    }
}

