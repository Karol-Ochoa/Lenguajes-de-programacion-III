﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KarolOchoa_Actividad2_Escritorio.CLASE
{
    public class ClassDividir
    {
        public float Dividir(float textNum1, float textNum2, float textNum3, float textNum4, float textNum5, float textNum6)
        {
            float resultado = textNum1 / textNum2 / textNum3 / textNum4 / textNum5 / textNum6;
            return resultado;
        }
    }
}

