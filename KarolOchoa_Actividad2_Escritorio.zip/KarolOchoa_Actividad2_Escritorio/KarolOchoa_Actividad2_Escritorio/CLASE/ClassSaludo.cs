﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KarolOchoa_Actividad2_Escritorio.CLASE
{
    public class ClassSaludo
    {
        public string Saludar (string nombre)
        {
            string saludo;
            saludo = "Hola " + nombre + ", ¿Qué tal va tu día?";
            return saludo;
        }
    }
}
