﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KarolOchoa_Actividad2_Escritorio.CLASE
{
    public class ClassSuma
    {
        public int Suma(int textNum1, int textNum2, int textNum3, int textNum4, int textNum5, int textNum6)
        {
            int resultado = textNum1 + textNum2 + textNum3 + textNum4 + textNum5 + textNum6;
            return resultado;
        }
    }
}
