﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KarolOchoa_Actividad2_Escritorio.CLASE
{
    internal class ClassOperacionesBasicas
    {
    }
}
